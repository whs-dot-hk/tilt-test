package foo

import (
	"fmt"
	"testing"
)

func TestBar(t *testing.T) {
	fmt.Println("everything's great!")
}

