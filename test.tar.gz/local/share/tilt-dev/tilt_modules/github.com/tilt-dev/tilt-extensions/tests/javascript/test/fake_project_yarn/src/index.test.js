test("everything is okay", () => {
    expect(1).toEqual(1)
});
